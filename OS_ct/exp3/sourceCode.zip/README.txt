fork : the result is not stable. For example, different processes scheduling is not determined before executed; Sometimes PPID of some child 
       process is 1 because its parent process has terminated.
